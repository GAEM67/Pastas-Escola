
    let nome;

    /* nome = 'TEXTO';
    nome1 = 2;

    alert(nome + nome1 + " seja bem vindo"); */

    nome = prompt("Digite seu nome")
    alert(nome + " seja\n bem vindo");
    
    document.write(nome + " seja<br>bem vindo")