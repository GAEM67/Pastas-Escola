function soma(){
    //parseInt()
    valor1 = parseInt(document.getElementById("txtValor1").value); //1
    valor2 = parseInt(document.getElementById("txtValor2").value); //2

    res = valor1 + valor2

    alert(res);
}