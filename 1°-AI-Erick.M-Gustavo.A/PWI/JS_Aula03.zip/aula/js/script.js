/* 
    i = 0;
    while(i < 10){
        document.write("JavaScript - WHILE<br>");
        i++;
    }

    for(i = 0;i < 10; i++){
        document.write("JavaScript - FOR<br>");
    }
     */

    function frase(){
        let frase = document.getElementById("txtfrase");
        let resp = document.getElementById("resp")
        let novaFrase = "";
        for(i = 0;i < 10; i++){
            novaFrase += frase.value + "<br>"
        }
        resp.innerHTML = novaFrase;
        frase.value = "";
    }