
function boasVindas(){
    let nome = document.getElementById("txtNome");

    if(nome.value == ""){
        alert("Campo obrigatório");
        nome.focus();
    }
    else{
        let elemento = document.getElementById("result");  
        elemento.innerHTML= nome.value + ", seja bem vindo!";
        nome.value="";
    }

    
}
